## This section includes advanced examples using OpenVINO™ toolkit:

- [Multiple models usage example](https://github.com/intel-iot-devkit/smart-video-workshop/blob/master/advanced-video-analytics/multiple_models.md)
- [Tensor Flow example](https://github.com/intel-iot-devkit/smart-video-workshop/blob/master/advanced-video-analytics/tensor_flow.md)
